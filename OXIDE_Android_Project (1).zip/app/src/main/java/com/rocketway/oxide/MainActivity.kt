package com.rocketway.oxide

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.RectF
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Switch
import android.widget.SeekBar
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(13, 14, 18)
    private val panel = Color.rgb(24, 26, 33)
    private val red = Color.rgb(255, 55, 76)
    private val muted = Color.rgb(165, 170, 185)
    private lateinit var arena: DemoArena
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(24))
        }

        val brand = TextView(this).apply {
            text = "O X I D E"
            textSize = 28f
            setTextColor(red)
            letterSpacing = 0.16f
            gravity = Gravity.CENTER_VERTICAL
            typeface = android.graphics.Typeface.create("sans-serif-black", 0)
        }
        content.addView(brand, matchWrap())

        val subtitle = TextView(this).apply {
            text = "ANDROID CONTROL PANEL  •  DEMO BUILD"
            textSize = 11f
            setTextColor(muted)
            letterSpacing = 0.08f
            setPadding(0, dp(4), 0, dp(18))
        }
        content.addView(subtitle, matchWrap())

        content.addView(sectionTitle("DEMO ARENA"))
        arena = DemoArena().apply {
            setBackgroundColor(Color.rgb(18, 20, 26))
        }
        content.addView(arena, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(220)
        ).apply { bottomMargin = dp(18) })

        content.addView(sectionTitle("FEATURES"))
        val espSwitch = addSwitch(content, "ESP Overlay", "Draws example markers in this app's demo arena", true)
        espSwitch.setOnCheckedChangeListener { _, checked ->
            arena.showEsp = checked
            arena.invalidate()
            updateStatus()
        }

        val aimSwitch = addSwitch(content, "Aim Assist UI", "Demo-only targeting reticle; does not control the game", false)
        aimSwitch.setOnCheckedChangeListener { _, checked ->
            arena.showAim = checked
            arena.invalidate()
            updateStatus()
        }

        content.addView(sectionTitle("AIM SETTINGS"))
        addLabel(content, "Sensitivity")
        val sensitivityValue = addLabel(content, "50%")
        val sensitivity = SeekBar(this).apply {
            max = 100
            progress = 50
            progressTintList = android.content.res.ColorStateList.valueOf(red)
            thumbTintList = android.content.res.ColorStateList.valueOf(red)
        }
        sensitivity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                sensitivityValue.text = "$progress%"
                arena.sensitivity = progress
                arena.invalidate()
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })
        content.addView(sensitivity, matchWrap())

        content.addView(sectionTitle("STATUS"))
        status = TextView(this).apply {
            textSize = 12f
            setTextColor(muted)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
        }
        content.addView(status, matchWrap())
        updateStatus()

        val footer = TextView(this).apply {
            text = "Standalone demo • Not connected to Oxide Survival Island"
            textSize = 10f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(4))
        }
        content.addView(footer, matchWrap())

        scroll.addView(content)
        page.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(page)
    }

    private fun updateStatus() {
        if (!::status.isInitialized) return
        status.text = "ESP: ${if (arena.showEsp) "ON" else "OFF"}    •    AIM UI: ${if (arena.showAim) "ON" else "OFF"}"
    }

    private fun sectionTitle(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(red)
        letterSpacing = 0.1f
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        setPadding(0, dp(12), 0, dp(10))
    }

    private fun addLabel(parent: LinearLayout, text: String): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.WHITE)
            parent.addView(this, matchWrap())
        }

    private fun addSwitch(parent: LinearLayout, title: String, description: String, initial: Boolean): Switch {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(panel)
        }
        val row = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        val textColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val heading = TextView(this).apply {
            text = title
            textSize = 15f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val desc = TextView(this).apply {
            text = description
            textSize = 10f
            setTextColor(muted)
            setPadding(0, dp(3), dp(8), 0)
        }
        textColumn.addView(heading, matchWrap())
        textColumn.addView(desc, matchWrap())
        row.addView(textColumn, LinearLayout.LayoutParams(0, -2, 1f))
        val sw = Switch(this).apply {
            isChecked = initial
            buttonTintList = android.content.res.ColorStateList.valueOf(red)
        }
        row.addView(sw)
        wrap.addView(row)
        parent.addView(wrap, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        return sw
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    inner class DemoArena : View(this@MainActivity) {
        var showEsp = true
        var showAim = false
        var sensitivity = 50
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val w = width.toFloat()
            val h = height.toFloat()
            p.color = Color.rgb(27, 31, 39)
            canvas.drawRect(0f, 0f, w, h, p)

            p.color = Color.rgb(37, 43, 53)
            p.strokeWidth = dp(1).toFloat()
            for (i in 1..5) canvas.drawLine(w * i / 6f, 0f, w * i / 6f, h, p)
            for (i in 1..3) canvas.drawLine(0f, h * i / 4f, w, h * i / 4f, p)

            p.color = muted
            p.textSize = dp(10).toFloat()
            canvas.drawText("TEST SCENE  /  LOCAL ONLY", dp(12).toFloat(), dp(18).toFloat(), p)

            if (showEsp) {
                val boxes = listOf(
                    RectF(w * .22f, h * .32f, w * .38f, h * .78f),
                    RectF(w * .61f, h * .28f, w * .76f, h * .70f)
                )
                boxes.forEachIndexed { index, box ->
                    p.style = Paint.Style.STROKE
                    p.color = red
                    p.strokeWidth = dp(2).toFloat()
                    canvas.drawRoundRect(box, dp(4).toFloat(), dp(4).toFloat(), p)
                    p.style = Paint.Style.FILL
                    p.color = red
                    p.textSize = dp(10).toFloat()
                    canvas.drawText("TARGET ${index + 1}", box.left, box.top - dp(6), p)
                    p.color = Color.rgb(255, 100, 115)
                    canvas.drawRect(box.left, box.bottom + dp(4), box.left + box.width() * .7f,
                        box.bottom + dp(7), p)
                }
            }

            if (showAim) {
                val cx = w / 2f
                val cy = h / 2f
                p.color = Color.WHITE
                p.style = Paint.Style.STROKE
                p.strokeWidth = dp(1).toFloat()
                val radius = dp(14 + sensitivity / 8).toFloat()
                canvas.drawCircle(cx, cy, radius, p)
                canvas.drawLine(cx - dp(24), cy, cx - dp(7), cy, p)
                canvas.drawLine(cx + dp(7), cy, cx + dp(24), cy, p)
                canvas.drawLine(cx, cy - dp(24), cx, cy - dp(7), p)
                canvas.drawLine(cx, cy + dp(7), cx, cy + dp(24), p)
                p.style = Paint.Style.FILL
            }
        }
    }
}
